
 const Artists = () => {
    return(
        [
            {
               artistId: 1,
               artistName : 'Liam sosma' ,
               artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:14,
               artistImage: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
               slug:"liam-sosma",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://cdn.pixabay.com/photo/2019/01/09/14/13/leaves-3923413__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Sun and world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://cdn.pixabay.com/photo/2019/04/21/21/29/pattern-4145023__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'meas',
                  },
                  {
                     artId: 4,
                     artImg: 'https://cdn.pixabay.com/photo/2014/10/04/17/27/glass-473758__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'bees',
                  }
               ]
            },
            {
                artistId: 2,
                artistName : 'madona William' ,
                artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:45,
                artistImage: 'https://images.unsplash.com/photo-1551547600-8d30c2559da8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80',
                slug:"madona-william",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1551547600-8d30c2559da8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://cdn.pixabay.com/photo/2018/07/18/15/43/animal-3546613__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://cdn.pixabay.com/photo/2017/04/06/19/37/sculpture-2209152_960_720.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                artistId: 3,
                artistName : 'Elijah Amelia' ,
                artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:52,
                artistImage: 'https://images.unsplash.com/photo-1503691341971-20427aa47194?ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80',
                slug:"elijah-amelia",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                artistId: 4,
                artistName : 'Amelia ss' ,
                artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:8,
                artistImage: 'https://images.unsplash.com/photo-1557104878-24bf6e92da73?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=889&q=80',
                slug:"amelia-ss",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                artistId: 5,
                artistName : 'Ethan ss' ,
                artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:10,
                artistImage: 'https://images.unsplash.com/photo-1526461117931-db8e99a3c7b9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
                slug:"ethan-ss",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
               artistId: 6,
               artistName : 'Isabella Harper' ,
               artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               artistImage: 'https://images.unsplash.com/photo-1526461117931-db8e99a3c7b9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
               slug:"isabella-harper",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
            {
               artistId: 7,
               artistName : 'Harper Evelyn' ,
               artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               artistImage: 'https://images.unsplash.com/photo-1572026490262-a421fcf0baac?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80',
               slug:"harper-Evelyn",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
            {
               artistId: 8,
               artistName : 'Jhon doe' ,
               artistDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               artistImage: 'https://images.unsplash.com/photo-1523245787856-3b2750746be9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=700&q=80',
               slug:"doe-Evelyn",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
        ]

    );
};

export default  Artists;