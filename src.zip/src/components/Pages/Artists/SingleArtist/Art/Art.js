import React, {useContext, useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'


export default function Art() {
    return (
        <div>
            
        </div>
    )
}
