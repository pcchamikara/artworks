
 const AlbumsData = () => {
    return(
        [
            {
               albumId: 1,
               albumName : 'Album 1' ,
               albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:14,
               albumImage: 'https://cdn.pixabay.com/photo/2018/05/21/23/10/steel-3419985__340.jpg',
               slug:"album-1",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://cdn.pixabay.com/photo/2014/10/04/17/27/glass-473758__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://cdn.pixabay.com/photo/2019/04/21/21/29/pattern-4145023__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://cdn.pixabay.com/photo/2015/10/12/15/21/paint-brushes-984434__340.jpg',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
            {
                albumId: 2,
                albumName : 'album 2' ,
                albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:45,
                albumImage: 'https://cdn.pixabay.com/photo/2017/04/06/19/37/sculpture-2209152_960_720.jpg',
                slug:"Album 2",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                albumId: 3,
                albumName : 'album 3' ,
                albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:52,
                albumImage: 'https://cdn.pixabay.com/photo/2019/08/19/09/24/banana-4415864__340.jpg',
                slug:"album-3",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                albumId: 4,
                albumName : 'album 4' ,
                albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:8,
                albumImage: 'https://images.unsplash.com/photo-1557104878-24bf6e92da73?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=889&q=80',
                slug:"amelia-ss",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
                albumId: 5,
                albumName : 'album 5' ,
                albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
                artworks:10,
                albumImage: 'https://images.unsplash.com/photo-1526461117931-db8e99a3c7b9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
                slug:"ethan-ss",
                arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
             },
             {
               albumId: 6,
               albumName : 'album 6' ,
               albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               albumImage: 'https://images.unsplash.com/photo-1526461117931-db8e99a3c7b9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80',
               slug:"isabella-harper",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
            {
               albumId: 7,
               albumName : 'Harper Evelyn' ,
               albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               albumImage: 'https://images.unsplash.com/photo-1572026490262-a421fcf0baac?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80',
               slug:"harper-Evelyn",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
            {
               albumId: 8,
               albumName : 'Jhon doe' ,
               albumDescription: 'lorem ipsan sda adaa das dsajsujjsdi sidisks adiaskda adisdsa k',
               artworks:10,
               albumImage: 'https://images.unsplash.com/photo-1523245787856-3b2750746be9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=700&q=80',
               slug:"doe-Evelyn",
               arts: [
                  {
                     artId: 1,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 2,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 3,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  },
                  {
                     artId: 4,
                     artImg: 'https://images.unsplash.com/photo-1544409527-b0bbb5ab0013?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=363&q=80',
                     artDescription: 'asd asdsadsadasd asd asd asdsadasd',
                     artTitle: 'Hellow world',
                  }
               ]
            },
        ]

    );
};

export default  AlbumsData;